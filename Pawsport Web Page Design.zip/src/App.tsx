import React from 'react';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { CommunityWall } from './components/CommunityWall';
import { CTA } from './components/CTA';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      <Features />
      <CommunityWall />
      <CTA />
      <Footer />
    </div>
  );
}