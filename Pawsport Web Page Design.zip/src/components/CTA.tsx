import React from 'react';
import { ArrowRight, CheckCircle, Sparkles } from 'lucide-react';
import mascotPassport from 'figma:asset/060d87472528e81e383cf593945e36e401df7200.png';

const benefits = [
  'Free consultation and quote',
  'Expert guidance every step',
  'Stress-free relocation',
  'Happy, safe pets',
];

export function CTA() {
  return (
    <section className="py-20 md:py-32 bg-gradient-to-br from-orange-400 via-pink-400 to-purple-500 text-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10">
        <div className="absolute top-10 right-20 text-white">
          <Sparkles className="w-24 h-24" />
        </div>
        <div className="absolute bottom-20 left-20 text-white">
          <Sparkles className="w-16 h-16" />
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 md:px-12 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left side - Mascot */}
          <div className="hidden md:block">
            <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-8 border-4 border-white/30">
              <img
                src={mascotPassport}
                alt="Pawsport mascot ready to help"
                className="w-full h-auto"
              />
            </div>
          </div>

          {/* Right side - CTA */}
          <div className="text-center md:text-left">
            <h2 className="text-4xl md:text-5xl mb-6">
              Start Planning Today! 🎉
            </h2>
            <p className="text-xl mb-8 opacity-95">
              Get your AI-powered travel plan in minutes. Join our community!
            </p>
            
            <div className="flex flex-wrap gap-3 mb-10 justify-center md:justify-start">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full border-2 border-white/30">
                  <CheckCircle className="w-5 h-5" />
                  <span>{benefit}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <button className="px-8 py-4 bg-white text-orange-600 rounded-full hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg flex items-center justify-center gap-2">
                Try AI Planning
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="px-8 py-4 border-2 border-white rounded-full hover:bg-white/10 transition-all backdrop-blur-sm">
                Explore Community
              </button>
            </div>

            <p className="mt-8 text-sm opacity-90">
              Free to start • No credit card required 💖
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}