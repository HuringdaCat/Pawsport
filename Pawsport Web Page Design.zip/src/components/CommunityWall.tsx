import React from 'react';
import { Heart, MessageCircle, MapPin, Sparkles } from 'lucide-react';
import mascotSuitcase from 'figma:asset/6475195566e55b58edbb829eeccedefde4ef148f.png';
import mascotTraveling from 'figma:asset/7f82bfc7f1fad2a41fcfdd125a755f73c6344760.png';
import mascotPair from 'figma:asset/9656bbaeee3ae8c8dca94c3af3f491c81c8f668b.png';

const posts = [
  {
    username: 'sarahpaws',
    location: 'London → Sydney',
    pet: 'Max the Golden',
    image: 'https://images.unsplash.com/photo-1731234412441-13bb57cac6a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRvZyUyMHRyYXZlbGluZ3xlbnwxfHx8fDE3NjUzMjk1NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    caption: 'Max loved his first international flight! ✈️',
    likes: 234,
    comments: 18,
  },
  {
    username: 'catmom_travels',
    location: 'NYC → Berlin',
    pet: 'Luna & Leo',
    image: 'https://images.unsplash.com/photo-1608060434411-0c3fa9049e7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXQlMjBwZXQlMjBjYXJyaWVyfGVufDF8fHx8MTc2NTMyOTU2MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    caption: 'Both cats settled in perfectly! 🐱',
    likes: 189,
    comments: 12,
  },
  {
    username: 'frenchie_adventures',
    location: 'Toronto → Amsterdam',
    pet: 'Bella',
    image: 'https://images.unsplash.com/photo-1723296014387-e6707dc62bc5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBtb3ZpbmclMjBwZXR8ZW58MXx8fHwxNzY1MzI5NTYwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    caption: 'Amsterdam parks are Bella approved! 🌷',
    likes: 312,
    comments: 24,
  },
  {
    username: 'travel_with_charlie',
    location: 'LA → Tokyo',
    pet: 'Charlie',
    image: 'https://images.unsplash.com/photo-1731234412441-13bb57cac6a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMGRvZyUyMHRyYXZlbGluZ3xlbnwxfHx8fDE3NjUzMjk1NTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    caption: 'First week in Tokyo going great! 🗾',
    likes: 276,
    comments: 31,
  },
];

export function CommunityWall() {
  return (
    <section className="py-20 md:py-32 bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 relative overflow-hidden">
      {/* Floating mascot decorations */}
      <div className="hidden lg:block absolute top-10 left-10 w-40 opacity-20 animate-bounce">
        <img
          src={mascotPair}
          alt="Pet friends"
          className="w-full h-auto"
        />
      </div>
      <div className="hidden lg:block absolute bottom-20 right-10 w-48 opacity-30">
        <img
          src={mascotTraveling}
          alt="Traveling pets"
          className="w-full h-auto transform hover:scale-110 transition-transform"
        />
      </div>
      
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-white border-2 border-pink-200 rounded-full mb-4 shadow-sm">
            <span className="bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">📸 Community Wall 📸</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-6">
            Pet Travel{' '}
            <span className="bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">Stories</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            See where other pets are traveling and share your own journey! 🌍
          </p>
        </div>

        {/* Instagram-style grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {posts.map((post, index) => (
            <div
              key={index}
              className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
            >
              <div className="aspect-square relative overflow-hidden group">
                <img
                  src={post.image}
                  alt={post.pet}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-6">
                  <div className="flex items-center gap-2 text-white">
                    <Heart className="w-6 h-6 fill-white" />
                    <span>{post.likes}</span>
                  </div>
                  <div className="flex items-center gap-2 text-white">
                    <MessageCircle className="w-6 h-6 fill-white" />
                    <span>{post.comments}</span>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <div className="mb-2">{post.username}</div>
                <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                  <MapPin className="w-4 h-4" />
                  <span>{post.location}</span>
                </div>
                <p className="text-sm text-gray-700">{post.caption}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Add a fun "post your own" card */}
        <div className="flex justify-center mb-12">
          <div className="bg-gradient-to-br from-orange-100 to-pink-100 rounded-3xl p-12 border-4 border-dashed border-orange-300 max-w-md text-center hover:border-solid hover:shadow-xl transition-all cursor-pointer transform hover:scale-105">
            <div className="text-6xl mb-4">📸</div>
            <h3 className="text-2xl mb-3">Share Your Adventure!</h3>
            <p className="text-gray-600 mb-6">Upload photos of your pet&apos;s journey and inspire other pet parents!</p>
            <button className="px-8 py-3 bg-gradient-to-r from-orange-400 to-pink-400 text-white rounded-full hover:shadow-lg transition-all transform hover:scale-105">
              Upload Photo
            </button>
          </div>
        </div>

        {/* Mascot with CTA */}
        <div className="flex justify-center">
          <div className="relative">
            <div className="bg-white rounded-3xl p-8 shadow-2xl border-4 border-purple-200 max-w-sm transform hover:scale-105 transition-transform hover:rotate-2">
              <img
                src={mascotSuitcase}
                alt="Pawsport mascot ready to share"
                className="w-full h-auto"
              />
            </div>
            <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-400 to-pink-400 text-white px-6 py-3 rounded-full shadow-lg whitespace-nowrap">
              <span>Share your story! 💕</span>
            </div>
            {/* Sparkle decorations */}
            <Sparkles className="absolute -top-6 -right-6 w-8 h-8 text-yellow-400 animate-pulse" />
            <Sparkles className="absolute -bottom-2 -left-6 w-6 h-6 text-pink-400 animate-pulse" />
          </div>
        </div>
      </div>
    </section>
  );
}