import React from 'react';
import { PawPrint, ArrowRight, Sparkles } from 'lucide-react';
import mascotPassport from 'figma:asset/060d87472528e81e383cf593945e36e401df7200.png';
import mascotPair from 'figma:asset/9656bbaeee3ae8c8dca94c3af3f491c81c8f668b.png';

export function Hero() {
  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-50">
      {/* Navigation */}
      <nav className="relative z-10 px-6 py-4 md:px-12">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-pink-400 rounded-2xl flex items-center justify-center shadow-lg transform rotate-12">
              <PawPrint className="w-7 h-7 text-white -rotate-12" />
            </div>
            <span className="text-2xl bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent">Pawsport</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-gray-700 hover:text-orange-600 transition-colors">Features</a>
            <a href="#how-it-works" className="text-gray-700 hover:text-orange-600 transition-colors">How It Works</a>
            <a href="#testimonials" className="text-gray-700 hover:text-orange-600 transition-colors">Testimonials</a>
            <button className="px-6 py-2 bg-gradient-to-r from-orange-400 to-pink-400 text-white rounded-full hover:shadow-lg transition-all transform hover:scale-105">
              Get Started
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-12 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm border-2 border-orange-200 rounded-full mb-6 shadow-sm">
              <Sparkles className="w-4 h-4 text-orange-500" />
              <span className="text-orange-700">AI-Powered Pet Travel</span>
            </div>
            <h1 className="text-5xl md:text-6xl mb-6">
              Plan Your Pet&apos;s{' '}
              <span className="bg-gradient-to-r from-orange-500 to-pink-500 bg-clip-text text-transparent">Perfect Journey!</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Get personalized travel plans with AI and share your pet&apos;s adventures with our community! 🐾
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="px-8 py-4 bg-gradient-to-r from-orange-400 to-pink-400 text-white rounded-full hover:shadow-lg transition-all transform hover:scale-105 flex items-center justify-center gap-2">
                Start Your Journey
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="px-8 py-4 bg-white border-2 border-orange-200 rounded-full hover:border-orange-300 transition-all hover:shadow-md">
                Learn More
              </button>
            </div>
          </div>
          <div className="relative">
            {/* Mascot Display */}
            <div className="relative bg-white rounded-3xl p-8 shadow-2xl border-4 border-orange-200">
              <img
                src={mascotPassport}
                alt="Pawsport mascot with passport"
                className="w-full h-auto"
              />
            </div>
            {/* Floating badge */}
            <div className="absolute -bottom-6 -left-6 bg-gradient-to-br from-orange-400 to-pink-400 text-white rounded-2xl shadow-xl p-6 hidden md:block transform rotate-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                  <PawPrint className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-2xl">10,000+</div>
                  <div className="text-white/90">Happy Pets!</div>
                </div>
              </div>
            </div>
            {/* Additional floating mascot */}
            <div className="absolute -top-8 -right-8 bg-white rounded-2xl p-4 shadow-xl border-4 border-pink-200 hidden lg:block w-48 animate-bounce">
              <img
                src={mascotPair}
                alt="Dog and cat friends"
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-pink-200 rounded-full blur-3xl opacity-40"></div>
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-orange-200 rounded-full blur-3xl opacity-40"></div>
      {/* Cute paw prints */}
      <div className="absolute top-32 right-1/4 text-orange-200 opacity-30 animate-pulse">
        <PawPrint className="w-16 h-16" />
      </div>
      <div className="absolute bottom-32 left-1/4 text-pink-200 opacity-30 animate-pulse">
        <PawPrint className="w-12 h-12 transform rotate-45" />
      </div>
      <div className="absolute top-1/2 left-20 text-purple-200 opacity-20 animate-bounce">
        <PawPrint className="w-10 h-10 transform -rotate-12" />
      </div>
    </div>
  );
}