import React from 'react';
import { PawPrint, Mail, Phone, MapPin, Heart } from 'lucide-react';
import mascotTraveling from 'figma:asset/7f82bfc7f1fad2a41fcfdd125a755f73c6344760.png';

export function Footer() {
  return (
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-gray-300 py-16 relative overflow-hidden">
      {/* Fun mascot in footer */}
      <div className="hidden lg:block absolute top-8 right-12 w-64 opacity-10">
        <img
          src={mascotTraveling}
          alt="Traveling pets"
          className="w-full h-auto"
        />
      </div>
      
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="flex items-center gap-3 text-white mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-pink-400 rounded-2xl flex items-center justify-center shadow-lg transform rotate-12">
                <PawPrint className="w-6 h-6 text-white -rotate-12" />
              </div>
              <span className="text-2xl bg-gradient-to-r from-orange-400 to-pink-400 bg-clip-text text-transparent">Pawsport</span>
            </div>
            <p className="text-gray-400">
              Making pet relocation stress-free for families worldwide! 🌍
            </p>
          </div>

          <div>
            <h3 className="text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#features" className="hover:text-orange-400 transition-colors">Features</a></li>
              <li><a href="#community" className="hover:text-orange-400 transition-colors">Community</a></li>
              <li><a href="#" className="hover:text-orange-400 transition-colors">About</a></li>
              <li><a href="#" className="hover:text-orange-400 transition-colors">FAQ</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-orange-400 transition-colors">Travel Tips</a></li>
              <li><a href="#" className="hover:text-orange-400 transition-colors">AI Planning Guide</a></li>
              <li><a href="#" className="hover:text-orange-400 transition-colors">Share Your Story</a></li>
              <li><a href="#" className="hover:text-orange-400 transition-colors">Support</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-orange-400" />
                <span>hello@pawsport.com</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-5 h-5 text-orange-400" />
                <span>1-800-PAWSPORT</span>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-orange-400" />
                <span>Available Worldwide</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
          <p className="flex items-center justify-center gap-2">
            &copy; 2025 Pawsport. All rights reserved. Made with 
            <Heart className="w-4 h-4 text-red-500 fill-red-500 animate-pulse" />
            for pets and their families.
          </p>
        </div>
      </div>
    </footer>
  );
}